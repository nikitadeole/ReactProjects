import Info from "./Info";
import Repos from "./Repos";
import User from "./User";
import Search from "./Search";
import Navbar from "./Navbar";

export { Info, Repos, User, Search, Navbar };
